#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

class GolfTournament {
private:
    Player* head;

public:
    GolfTournament() { head = NULL; }

    void addPlayer(string name, int score) {
        Player* newPlayer = new Player{name, score, NULL, NULL};
        if (!head || head->score > score) {
            newPlayer->next = head;
            if (head) head->prev = newPlayer;
            head = newPlayer;
            return;
        }
        Player* temp = head;
        while (temp->next && temp->next->score <= score)
            temp = temp->next;
        newPlayer->next = temp->next;
        newPlayer->prev = temp;
        if (temp->next) temp->next->prev = newPlayer;
        temp->next = newPlayer;
    }

    void deletePlayer(string name) {
        Player* temp = head;
        while (temp && temp->name != name)
            temp = temp->next;
        if (!temp) {
            cout << "Player not found!\n";
            return;
        }
        if (temp->prev) temp->prev->next = temp->next;
        else head = temp->next;
        if (temp->next) temp->next->prev = temp->prev;
        delete temp;
        cout << "Player deleted!\n";
    }

    void displayAll() {
        Player* temp = head;
        while (temp) {
            cout << temp->name << " - " << temp->score << endl;
            temp = temp->next;
        }
    }

    void displayLowest() {
        if (head)
            cout << "Lowest Score: " << head->name << " - " << head->score << endl;
        else
            cout << "No players available!\n";
    }

    void displaySameScore(int score) {
        Player* temp = head;
        bool found = false;
        while (temp) {
            if (temp->score == score) {
                cout << temp->name << endl;
                found = true;
            }
            temp = temp->next;
        }
        if (!found) cout << "No players with this score!\n";
    }

    void displayBackward(string name) {
        Player* temp = head;
        while (temp && temp->name != name)
            temp = temp->next;
        if (!temp) {
            cout << "Player not found!\n";
            return;
        }
        while (temp) {
            cout << temp->name << " - " << temp->score << endl;
            temp = temp->prev;
        }
    }
};

int main() {
    GolfTournament tournament;
    int choice;
    string name;
    int score;
 do {
        cout << "\n1. Add Player\n2. Delete Player\n3. Display All Players\n4. Display Lowest Score\n5. Display Players with Same Score\n6. Display Backward from Player\n7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
   

        switch (choice) {
            case 1:
                cout << "Enter player name: ";
                cin >> name;
                cout << "Enter player score: ";
                cin >> score;
                tournament.addPlayer(name, score);
                 cout << "PLAYER ADDED ";
                break;
            case 2:
                cout << "Enter player name to delete: ";
                cin >> name;
                tournament.deletePlayer(name);
                cout << "PLAYER DELETED ";
                break;
            case 3:
                cout << "All Players:";
                tournament.displayAll();
                break;
            case 4:
                cout << "Lowest Score:";
                tournament.displayLowest();
                break;
            case 5:
                cout << "Enter score to find players: ";
                cin >> score;
                cout << "Players with score " << score << ":\n";
                tournament.displaySameScore(score);
                break;
            case 6:
                cout << "Enter player name to display backward: ";
                cin >> name;
                tournament.displayBackward(name);
                break;
            case 7:
                cout << "Exiting...";
                break;
            default:
                cout << "Invalid choice! Please try again.";
        }
    } while (choice != 7);

    return 0;
}