#include <iostream>
#include <string>
using namespace std;

class Applicant {
public:
    int applicant_id;
    int height;
    int weight;
    string eyesight;
    string status;
    Applicant* next;

   Applicant(int id, int h, int w, string e, string s)
       : applicant_id(id), height(h), weight(w), eyesight(e), status(s), next(nullptr) {}
      
};

class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() : front(nullptr), rear(nullptr) {}

    void enqueue(Applicant* applicant) {
        if (rear == nullptr) {
            front = rear = applicant;
        } else {
            rear->next = applicant;
            rear = applicant;
        }
    }

    Applicant* dequeue() {
        if (front == nullptr) {
            return nullptr;
        }
        Applicant* removed_applicant = front;
        front = front->next;
        if (front == nullptr) {
            rear = nullptr;
        }
        return removed_applicant;
    }

    void display() {
        Applicant* current = front;
        while (current) {
            cout << "Applicant ID: " << current->applicant_id
                      << ", Height: " << current->height
                      << ", Weight: " << current->weight
                      << ", Eyesight: " << current->eyesight
                      << ", Status: " << current->status << std::endl;
            current = current->next;
        }
    }

    void removeSecondApplicant() {
        if (front == nullptr || front->next == nullptr) {
            return; 
        }
        Applicant* second_applicant = front->next;
        front->next = second_applicant->next;
        if (second_applicant->next == nullptr) {
            rear = front; 
        }
        delete second_applicant; 
    }
};

int main() {
    ApplicantQueue applicantQueue;

    for (int i = 1; i <= 7; ++i) {
        Applicant* applicant = new Applicant(i, 170 + i, 60 + i, "20/20", "Waiting ");
        applicantQueue.enqueue(applicant);
    }

    cout << "Initial Queue:" <<endl;
    applicantQueue.display();

 cout << "\nApplicant at 2nd position leaves the queue." <<endl;
    applicantQueue.removeSecondApplicant();

  cout << "Queue after removing the 2nd applicant:" <<endl;
    applicantQueue.display();

cout << "\nApplicant at front takes the test and leaves the queue." <<endl;
    Applicant* front_applicant = applicantQueue.dequeue();
    delete front_applicant; 

   cout << "Queue after the front applicant leaves:" <<endl;
    applicantQueue.display();
    
    return 0;
}