#include <iostream>
#include <queue>
#include <stack>

using namespace std;

int main() {
    queue<int> road;
    stack<int> garage;

    road.push(2);
    road.push(5);
    road.push(10);
    road.push(9);
    road.push(22);

    cout << "Road Vehicle: ";
    queue<int> tempRoad = road;
    while (!tempRoad.empty()) {
        cout << tempRoad.front() << " ";
        tempRoad.pop();
    }
    cout << endl;

  
    cout << "Garage Vehicle: Empty" << endl;

    if (!road.empty() && road.front() == 2) {
        road.pop();
        garage.push(2);
    }

   
    cout << "Road Vehicle: ";
    tempRoad = road;
    while (!tempRoad.empty()) {
        cout << tempRoad.front() << " ";
        tempRoad.pop();
    }
    cout << endl;

    cout << "Garage Vehicle: ";
    stack<int> tempGarage = garage;
    while (!tempGarage.empty()) {
        cout << tempGarage.top() << " ";
        tempGarage.pop();
    }
    cout << endl;

   
    if (!road.empty() && road.front() == 10) {
        road.pop();
        garage.push(10);
    } else {
        cout << "Error: 10 NO. Vehicle cannot enter into garage." << endl;
    }

    if (!road.empty() && road.front() == 5) {
        road.pop();
        garage.push(5);
    }

    if (!garage.empty() && garage.top() == 2) {
        garage.pop();
        cout << "2 No. vehicle leaving garage" << endl;
    } else {
        cout << "Error: 2 No. vehicle cannot exit garage." << endl;
    }


    if (!garage.empty() && garage.top() == 5) {
        garage.pop();
        cout << "5 No. vehicle leaving garage" << endl;
    }


    cout << "Garage Vehicle: ";
    tempGarage = garage;
    while (!tempGarage.empty()) {
        cout << tempGarage.top() << " ";
        tempGarage.pop();
    }
    cout << endl;

    return 0;
}
